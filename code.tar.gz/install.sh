#!/bin/bash
sudo yum install httpd -y
