#!/bin/bash

sudo su root
sudo yum install httpd -y 
