#!/bin/bash

chmod 664 /var/www/html/index.html
